package ptolemy;
import helper.Mathf;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Duration;

public class PtPlanet
{   
    public enum AXIS_POINT
    {
        Select,
        Earth,
        Deferent,
        Equant,
        Epicyclic,
        Planet;
        
        @Override
        public String toString()
        {
            if (this == Select)
            {
                return "Select...";
            }
            else
            {
                return super.toString();
            }
        }
    };
    public static AXIS_POINT GetAxisPoint(String axisPointName)
    {
        for (AXIS_POINT axisPoint : AXIS_POINT.values())
        {
            if (axisPoint.toString().equals(axisPointName))
            {
                return axisPoint;
            }
        }
        
        return null;
    }
    public static Point GetPointOfAxis(AXIS_POINT axisPoint, PtPlanet planet)
    {
        int x=0,
            y=0;
        
        switch (axisPoint)
        {
        case Deferent:
            x = (int) planet.defCenterX;
            y = (int) planet.defCenterY;
            break;
        case Equant:
            x = (int) planet.eqCenterX;
            y = (int) planet.eqCenterY;
            break;
        case Epicyclic:
            x = (int) planet.epiCenterX;
            y = (int) planet.epiCenterY;
            break;
        case Planet:
            x = (int) planet.planetX;
            y = (int) planet.planetY;
            break;
        case Earth:
            x = y = 0;
            break;
        default:
            x = y = 0;
            break;
        }
        
        return new Point(x, y);
    }
    
    public enum SIGN
    {
        Aries (0),
        Taurus (1),
        Gemini (2),
        Cancer (3),
        Leo (4),
        Virgo (5),
        Libra (6),
        Scorpio (7),
        Sagittarius (8),
        Capricorn (9),
        Aquarius (10),
        Pisces (11);
        
        private int _degrees = 0;
        public int getDegrees()
        {
            return _degrees;
        }
        
        private SIGN(int value)
        {
            _degrees = value * 30;
        }
    };
    
    // PLANET PROPERTIES
    
    // name is locked in for non-custom planets, and changeable for custom ones
    private String name;
    
    // size, orbitRadius, and color are completely arbitrary and can be changed at the user's whim
    private int size, deferentRadius;
    private Color color;
    
    // eccentric measurement
    private double eccentricityRatio; // ratio between the radius of the orbit and the eccentric offset (also the radius of the epicycle)
    private double deferentOrbitSpeedRatio; // in ratio to the mean sun
    
    private double epicyclicRadiusRatio;
    private double epicyclicSpeedRatio; // in ratio to the mean sun
    
    private double epochMean; // in degrees, convert to radians before passing through trig functions
    private double epochAnomaly; // in degrees, convert to radians before passing through trig functions
    private double epochApogee; // in degrees, convert to radians before passing through trig functions
    
    // The time at which the angleOnDeferent and angleOnEpicycle are the same as the eccentricityDirection
    
    
    // These are private and depend, among other things, on the current time
    private double angleOnDeferent, angleOnEpicycle;
    
    // a display question
    private boolean hasEquantCenter = true;
    
    // changes the changeability of these variables
    private boolean isCustom;
    
    // DISPLAY PROPERTIES
    private boolean enabled = true;
    private boolean showPlanet = true;
    private boolean showDeferentRadius = true;
    private boolean showEpicyclicRadius = true;
    
    private List<Axis> axes;
    
    // TIME VARIABLE
    
    // Important variable -- everything else calculates position based on this
    private DateTime currentTime;
    
    // PRIVATE VARIABLES
    
    // Private location variables
    private double defCenterX, defCenterY, eqCenterX, eqCenterY, epiCenterX, epiCenterY, planetX, planetY;
    
    // *********
    // Display variables
    
    //private boolean showAll = true;
    
    public PtPlanet(String newName, int newSize, int newDeferentRadius, Color newColor,
            double newEccentricRatio, double newEpicycleRadiusRatio,
            double newOrbitSpeedRatio, double newEpicyclicSpeedRatio,
            double newEpochMean, double newEpochAnomaly, double newEpochApogee,
            boolean newHasEquantCenter, boolean newIsCustom)
    {
        name = newName;
        size = newSize;
        deferentRadius = newDeferentRadius;
        color = newColor;
        
        eccentricityRatio = newEccentricRatio;
        epicyclicRadiusRatio = newEpicycleRadiusRatio;
        
        epochMean = newEpochMean;
        epochAnomaly = newEpochAnomaly;
        epochApogee = newEpochApogee;
        
        deferentOrbitSpeedRatio = newOrbitSpeedRatio;
        epicyclicSpeedRatio = newEpicyclicSpeedRatio;
        
        hasEquantCenter = newHasEquantCenter;
        
        isCustom = newIsCustom;
        
        axes = new ArrayList<Axis>();
        if (name.equals("Earth"))
        {
            axes.add(new Axis(AXIS_POINT.Select, AXIS_POINT.Select, false));
        }
        else
        {
            axes.add(new Axis(AXIS_POINT.Earth, AXIS_POINT.Deferent));
            axes.add(new Axis(AXIS_POINT.Deferent, AXIS_POINT.Epicyclic));
            axes.add(new Axis(AXIS_POINT.Epicyclic, AXIS_POINT.Planet));
        }
        
        currentTime = new DateTime();
        setCurrentTime(currentTime);
    }
    
    // Getting and setting the current time are bigger functions, so they're down here
    public DateTime getCurrentTime()
    {
        return currentTime;
    }
    public void setCurrentTime(DateTime newCurrentTime)
    {
        //System.out.println("Went ahead " + new Period(currentTime, newCurrentTime).getMonths() + " months!");
        currentTime = new DateTime(newCurrentTime);
        
        Duration duration = new Duration(Mathf.MOMENT_OF_EPOCH.getMillis(), currentTime.getMillis());
        
        double timeElapsedInMeanSuns = duration.getMillis() / 86400000D / Mathf.NUMBER_OF_DAYS_IN_A_YEAR;
        
        double rotationOfSame = (Ptolemy.planetManager == null) ? 0D : Ptolemy.planetManager.rotationOfTheSame;
        
        // Now, calculate position of planet and other elements, relative to the center of the universe (aka the Earth)
        double eccDirInRad = Mathf.DegToRad(epochApogee + rotationOfSame);
        
        angleOnDeferent = (eccDirInRad + Mathf.DegToRad(epochMean) + Math.PI * 2 * deferentOrbitSpeedRatio * timeElapsedInMeanSuns) % (Math.PI * 2);
        angleOnEpicycle = (angleOnDeferent - Mathf.DegToRad(epochAnomaly) - Math.PI * 2 * epicyclicSpeedRatio * timeElapsedInMeanSuns) % (Math.PI * 2);
        
        // Find the deferent center
        defCenterX = Math.sin(eccDirInRad) * deferentRadius * eccentricityRatio;
        defCenterY = Math.cos(eccDirInRad) * deferentRadius * eccentricityRatio;
        
        eqCenterX = defCenterX;
        eqCenterY = defCenterY;
        
        // Find the equant center
        if (hasEquantCenter)
        {
            eqCenterX *= 2;
            eqCenterY *= 2;
            
            // Find the epicycle center
            // Every planet has an epicycle, just some have a radius of 0!
            // **************************
            // IF HASEQUANTCENTER IS TRUE, USE THE EQUANT CENTER TO CALCULATE THE EPICENTER
            // **************************
            epiCenterX = defCenterX + Math.sin(eccDirInRad + calculateDeferentAngleFromEquantAngle(angleOnDeferent - eccDirInRad)) * deferentRadius;
            epiCenterY = defCenterY + Math.cos(eccDirInRad + calculateDeferentAngleFromEquantAngle(angleOnDeferent - eccDirInRad)) * deferentRadius;
            
            //epiCenterX = defCenterX + Math.sin(angleOnDeferent) * deferentRadius;
            //epiCenterY = defCenterY + Math.cos(angleOnDeferent) * deferentRadius;
            
            //System.out.println("Deferent from 0 is " + calculateDeferentAngleFromEquantAngle(0D));
            //System.out.println("Deferent from 180 is " + calculateDeferentAngleFromEquantAngle(Mathf.DegToRad(180D)));
        }
        else
        {
            epiCenterX = defCenterX + Math.sin(angleOnDeferent) * deferentRadius;
            epiCenterY = defCenterY + Math.cos(angleOnDeferent) * deferentRadius;
        }
        
        // Find the planet's position!
        planetX = epiCenterX + Math.sin(angleOnEpicycle) * deferentRadius * epicyclicRadiusRatio;
        planetY = epiCenterY + Math.cos(angleOnEpicycle) * deferentRadius * epicyclicRadiusRatio;
    }
    
    private double calculateDeferentAngleFromEquantAngle(double equantAngle)
    {
        // Reference drawing: http://www.mathpages.com/home/kmath639/kmath639.htm
        
        // By law of sines:
        // sin (180 - b) / R = sin (b - a) / E
        //
        // E sin (180 - b) = R sin (b - 1)
        // sin-1 ( E sin (180 - b) / R ) = b - a
        // so
        // a = b - sin-1 (E sin (180 - b) / R)
        // and
        // a = angleOnDeferent
        // b = equantAngle
        // R = deferentRadius
        // E = deferentRadius * eccentricityRatio
        
        double deferentAngle = equantAngle - Math.asin(deferentRadius * eccentricityRatio * Math.sin(Mathf.DegToRad(180) - equantAngle) / deferentRadius);
        
        //if (name.equals("Mars"))
        //  System.out.println(name + ": Calculated " + equantAngle + " to be " + deferentAngle);
        
        return deferentAngle;
    }
    
    @Override
    public String toString()
    {
        return name;
    }
    
    // ***************************
    // PUBLIC SETTERS AND GETTERS
    // ***************************
    
    public String getName()
    {
        return name;
    }
    public void setName(String newName)
    {
        if (isCustom)
        {
            name = newName;
        }
        else
        {
            System.out.println("You can't rename " + name + "!");
        }
    }
    
    public int getSize()
    {
        return size;
    }
    public void setSize(int newSize)
    {
        this.size = newSize;
    }
    public int getDeferentRadius()
    {
        return deferentRadius;
    }
    public void setDeferentRadius(int newDeferentRadius)
    {
        this.deferentRadius = newDeferentRadius;
    }
    public Color getColor()
    {
        return color;
    }
    public void setColor(Color newColor)
    {
        this.color = newColor;
    }
    
    public double getEccentricRatio()
    {
        return eccentricityRatio;
    }
    public void setEccentricRatio(double newEccentricityRatio)
    {
        if (isCustom)
        {
            this.eccentricityRatio = newEccentricityRatio;
        }
        else
        {
            System.out.println("You can't change the eccentric ratio of " + name + "!");
        }
    }
    public double getEccentricDirection()
    {
        return epochApogee;
    }
    public void setEccentricDirection(double newEccentricityDirection)
    {
        if (isCustom)
        {
            this.epochApogee = newEccentricityDirection;
        }
        else
        {
            System.out.println("You can't change the eccentric direction of " + name + "!");
        }
    }
    public double getEpicyclicRadiusRatio()
    {
        return epicyclicRadiusRatio;
    }
    public void setEpicyclicRadiusRatio(double newEpicyclicRadiusRatio)
    {
        if (isCustom)
            this.epicyclicRadiusRatio = newEpicyclicRadiusRatio;
        else
            System.out.println("You can't change the epicyclic radius ratio of " + name + "!");
    }
    public double getOrbitSpeedRatio()
    {
        return deferentOrbitSpeedRatio;
    }
    public void setOrbitSpeedRatio(double newOrbitSpeedRatio)
    {
        if (isCustom)
            this.deferentOrbitSpeedRatio = newOrbitSpeedRatio;
        else
            System.out.println("You can't change the orbit speed ratio of " + name + "!");
    }
    public double getEpicyclicSpeedRatio()
    {
        return epicyclicSpeedRatio;
    }
    public void setEpicyclicSpeedRatio(double newEpicyclicSpeedRatio)
    {
        if (isCustom)
            this.epicyclicSpeedRatio = newEpicyclicSpeedRatio;
        else
            System.out.println("You can't change the epicyclic speed ratio of " + name + "!");
    }
    
    public boolean getHasEquantCenter()
    {
        return hasEquantCenter;
    }
    public void setHasEquantCenter(boolean newHasEquantCenter)
    {
        if (isCustom)
        {
            this.hasEquantCenter = newHasEquantCenter;
        }
        else
        {
            System.out.println("You can't change whether " + name + " has an equant center or not!");
        }
    }
    
    public double getDefCenterX()
    {
        return defCenterX;
    }
    public double getDefCenterY()
    {
        return defCenterY;
    }
    public double getEqCenterX()
    {
        return eqCenterX;
    }
    public double getEqCenterY()
    {
        return eqCenterY;
    }
    public double getEpiCenterX()
    {
        return epiCenterX;
    }
    public double getEpiCenterY()
    {
        return epiCenterY;
    }
    public double getPlanetX()
    {
        return planetX;
    }
    public double getPlanetY()
    {
        return planetY;
    }
    
    public boolean getIsCustom()
    {
        return isCustom;
    }
    
    public boolean getEnabled()
    {
        return enabled;
    }
    public void setEnabled(boolean newEnabled)
    {
        enabled = newEnabled;
    }
    public boolean getShowPlanet()
    {
        return showPlanet;
    }
    public void setShowPlanet(boolean newShowPlanet)
    {
        showPlanet = newShowPlanet;
    }
    public boolean getShowDeferentRadius()
    {
        return showDeferentRadius;
    }
    public void setShowDeferentRadius(boolean newShowDeferentRadius)
    {
        showDeferentRadius = newShowDeferentRadius;
    }
    public boolean getShowEpicyclicRadius()
    {
        return showEpicyclicRadius;
    }
    public void setShowEpicyclicRadius(boolean newShowEpicyclicRadius)
    {
        showEpicyclicRadius = newShowEpicyclicRadius;
    }
    
    public Axis[] getAllAxes()
    {
        if (axes != null)
        {
            return axes.toArray(new Axis[axes.size()]);
        }
        else
        {
            return null;
        }
    }
    public Axis getAxisAtIndex(int index)
    {
        return axes.get(index);
    }
    public void insertAxisAtIndex(Axis newAxis, int index)
    {
        axes.add(index, newAxis);
    }
    public void deleteAxisAtIndex(int index)
    {
        axes.remove(index);
    }
    
    public class Axis
    {
        // Public

        public Axis(AXIS_POINT newPoint1, AXIS_POINT newPoint2)
        {
            this(newPoint1, newPoint2, true);
        }
        public Axis(AXIS_POINT newPoint1, AXIS_POINT newPoint2, boolean newIsEnabled)
        {
            point1 = newPoint1;
            point2 = newPoint2;
            
            isEnabled = newIsEnabled;
        }

        public AXIS_POINT getPoint1()
        {
            return point1;
        }

        public AXIS_POINT getPoint2()
        {
            return point2;
        }

        public boolean getIsEnabled()
        {
            return isEnabled;
        }

        // Private
        
        private AXIS_POINT point1;
        private AXIS_POINT point2;
        private boolean isEnabled = true;
    }
}
