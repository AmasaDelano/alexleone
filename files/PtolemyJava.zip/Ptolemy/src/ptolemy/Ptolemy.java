package ptolemy;
import helper.Systemf;


public class Ptolemy {

	public static PtGuiManager guiManager;
	public static PtPlanetManager planetManager;
	
	public static void main(String[] args)
	{
		Systemf.setSystemLookAndFeel();
		
		guiManager = new PtGuiManager();
		planetManager = new PtPlanetManager();
		
		guiManager.setManager(planetManager);
		
		guiManager.createWindow();
		guiManager.refreshHeavens();
	}

}
