package ptolemy;
import helper.Mathf;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;


public class PtPlanetManager
{
	private List<PtPlanet> planets;
	private DateTime currentTime;
	
	private PtHeavenThread watchingThread;
	public boolean isThreadRunning()
	{
		return (watchingThread != null && watchingThread.isAlive());
	}
	
	public boolean showZodiacSigns = true;
	public double rotationOfTheSame = 0D;
	
	public PtPlanetManager()
	{
		planets = new ArrayList<PtPlanet>();
		currentTime = new DateTime();
		
		planets.add(getDefaultEarth());
		planets.add(getDefaultSunDeferent());
		planets.add(getDefaultSunEpicyclic());
		planets.add(getDefaultVenus());
		planets.add(getDefaultMars());
		planets.add(getDefaultJupiter());
		planets.add(getDefaultSaturn());
		
		setTime(currentTime);
	}
	

	/* 
	 * PARAMETERS:
	 * name, size, orbitSize, color (all arbitrary, can be easily changed)
	 * eccentricRatio,
	 * epicycleRadiusRatio,
	 * orbitSpeedRatio (in ratio to the speed of the mean sun)
	 * epicyclicSpeedRatio (in ratio to the speed of the mean sun)
	 * epochMean,
	 * epochAnomaly,
	 * epochApogee,
	 * hasEquantCenter, isCustom
	 */
	private PtPlanet getDefaultEarth()
	{
		return new PtPlanet(
				"Earth", 2, 0, Color.green,
				1,
				0,
				0,
				0,
				0,
				0,
				0,
				false, false);
	}
	private PtPlanet getDefaultSunDeferent()
	{
		return new PtPlanet(
				"Sun (Deferent)", 7, 100, Color.yellow,
				Mathf.PtHexToDec(2, 29.5) / 60, // H236: EZ = 2;29.5p where the radius of the eccentre = 60p, so the ratio is (2+29.5/60)
				0D,
				1D,
				1D,
				PtPlanet.SIGN.Pisces.getDegrees() + Mathf.PtHexToDec(0, 45), // H263
				PtPlanet.SIGN.Pisces.getDegrees() + Mathf.PtHexToDec(3, 8), // H263
				PtPlanet.SIGN.Gemini.getDegrees() + Mathf.PtHexToDec(5, 30), // H256, H257
				false, false);
	}
	private PtPlanet getDefaultSunEpicyclic()
	{
		return new PtPlanet(
				"Sun (Epicyclic)", 7, 100, Color.yellow,
				0D,
				Mathf.PtHexToDec(2, 29.5) / 60, // see above, also H226
				1D,
				1D,
				PtPlanet.SIGN.Pisces.getDegrees() + Mathf.PtHexToDec(0, 45), // H263
				PtPlanet.SIGN.Pisces.getDegrees() + Mathf.PtHexToDec(3, 8), // H263
				PtPlanet.SIGN.Gemini.getDegrees() + Mathf.PtHexToDec(5, 30), // see above
				false, false);
	}
	/* PARAMETERS:
	 * name, size, orbitSize, color (all arbitrary, can be easily changed)
	 * eccentricRatio,
	 * epicycleRadiusRatio,
	 * orbitSpeedRatio (in ratio to the speed of the mean sun)
	 * epicyclicSpeedRatio (in ratio to the speed of the mean sun)
	 * epochMean,
	 * epochAnomaly,
	 * epochApogee,
	 * hasEquantCenter, isCustom
	 */
	private PtPlanet getDefaultVenus()
	{
		return new PtPlanet(
				"Venus", 8, 100, Color.cyan,
				Mathf.PtHexToDec(1, 15) / 60, // H302: DE is about 1;15p to deferent radius AD, which is 60p, so 1;15/60
				Mathf.PtHexToDec(43, 10) / 60, // H302: AZ = 43;10p of 60p deferent radius AD, so 43;10/60
				Mathf.PtDegToYears(Mathf.PtHexToDec(8 * 360 - 2 - 1, 60 - 15)) / Mathf.PtHexToDec(8 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR - 2 - 1, 60 - 18),
				(5D * Mathf.NUMBER_OF_DAYS_IN_A_YEAR) / ((8 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR) - Mathf.PtHexToDec(2, 18)), // H215: 5 epicyclic rotations to 8 mean sun rotations less 2;18 days
				PtPlanet.SIGN.Pisces.getDegrees() + Mathf.PtHexToDec(0, 45),
				Mathf.PtHexToDec(71, 7),
				PtPlanet.SIGN.Taurus.getDegrees() + Mathf.PtHexToDec(16, 10), // H316 & H250
				true, false);
	}
	private PtPlanet getDefaultMars()
	{
		return new PtPlanet(
				"Mars", 6, 150, Color.red,
				6D / 60, // H342: D-theta = 6p after the corrections
				Mathf.PtHexToDec(39, 30) / 60, // H351: BN = 39;30
				Mathf.PtDegToYears(Mathf.PtHexToDec(32 * 360 + 3, 10)) / Mathf.PtHexToDec(79 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR + 3, 13), // H215: 79 years plus 3;13 days to 32 years plus 3 1/6 degrees
				(37 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR) / Mathf.PtHexToDec(79 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR + 3, 13), // H215: 37 returns in anomaly to 79 years plus 3;13 days 
				PtPlanet.SIGN.Aries.getDegrees() + Mathf.PtHexToDec(3, 32),
				Mathf.PtHexToDec(327, 13),
				PtPlanet.SIGN.Cancer.getDegrees() + Mathf.PtHexToDec(16, 40), // H250
				true, false);
	}
	private PtPlanet getDefaultJupiter()
	{
		return new PtPlanet(
				"Jupiter", 11, 250, Color.orange,
				Mathf.PtHexToDec(2, 45) / 60, // H379: DZ = 2;45p
				Mathf.PtHexToDec(11, 30) / 60, // H386: BK = 11;30p
				Mathf.PtDegToYears(Mathf.PtHexToDec(6 * 360 - 4 - 1, 60 - 50)) / Mathf.PtHexToDec(71 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR - 4 - 1, 60 - 54), // H215
				(65 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR) / Mathf.PtHexToDec(71 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR - 4 - 1, 60 - 54), // H215
				PtPlanet.SIGN.Libra.getDegrees() + Mathf.PtHexToDec(4, 41),
				Mathf.PtHexToDec(146, 4),
				PtPlanet.SIGN.Virgo.getDegrees() + Mathf.PtHexToDec(2, 9), // H250,
				true, false);
	}
	/* PARAMETERS:
	 * name, size, orbitSize, color (all arbitrary, can be easily changed)
	 * eccentricRatio,
	 * epicycleRadiusRatio,
	 * orbitSpeedRatio (in ratio to the speed of the mean sun)
	 * epicyclicSpeedRatio (in ratio to the speed of the mean sun)
	 * epochMean,
	 * epochAnomaly,
	 * epochApogee,
	 * hasEquantCenter, isCustom
	 */
	private PtPlanet getDefaultSaturn()
	{
		return new PtPlanet(
				"Saturn", 8, 350, Color.LIGHT_GRAY,
				Mathf.PtHexToDec(3, 25) / 60, // H411: DZ = 3;25p
				Mathf.PtHexToDec(6, 30) / 60, // H419
				Mathf.PtDegToYears(Mathf.PtHexToDec(2 * 360 + 1, 43)) / Mathf.PtHexToDec(59 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR + 1, 45), // H215
				(57D * Mathf.NUMBER_OF_DAYS_IN_A_YEAR) / Mathf.PtHexToDec(59 * Mathf.NUMBER_OF_DAYS_IN_A_YEAR + 1, 45), // H215
				PtPlanet.SIGN.Capricorn.getDegrees() + Mathf.PtHexToDec(26, 43),
				Mathf.PtHexToDec(34, 2),
				PtPlanet.SIGN.Scorpio.getDegrees() + Mathf.PtHexToDec(14, 10), // H250
				true, false);
	}
	
	public DateTime getTime()
	{
		return currentTime;
	}
	public void setTime(DateTime newTime)
	{
		currentTime = newTime;
		for (PtPlanet planet : planets)
		{
			planet.setCurrentTime(currentTime);
		}
	}
	
	public PtPlanet[] getPlanets()
	{
		return planets.toArray(new PtPlanet[planets.size()]);
	}
	
	public void startMotion(long showSeconds, long inSeconds)
	{
		watchingThread = new PtHeavenThread(showSeconds, inSeconds);
		watchingThread.start();
	}
	public void stopMotion()
	{
		watchingThread.shouldRun = false;
	}
	
	public void updateSpeed(long showSeconds, long inSeconds)
	{
		if (isThreadRunning())
		{
			watchingThread.setShowSeconds(showSeconds);
			watchingThread.setInSeconds(inSeconds);
		}
	}
	
	public void addAxisToPlanet()
	{
		
	}
	
}
