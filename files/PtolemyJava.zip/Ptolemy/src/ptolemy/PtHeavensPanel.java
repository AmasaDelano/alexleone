package ptolemy;
import helper.Mathf;
import helper.Systemf;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class PtHeavensPanel extends JPanel
{
	private static final long serialVersionUID = -6784609792339510199L;
	
	private int zoom = 100;
	public int getZoom() { return zoom; }
	public void setZoom(int newZoom) { zoom = newZoom; }

	private Image[] zodiacImages;
	
	public PtHeavensPanel()
	{
		super();
		
		loadZodiacImages();
		
		setPreferredSize(new Dimension(600, 400));
	}
	
	private void loadZodiacImages()
	{
		PtPlanet.SIGN[] allSigns = PtPlanet.SIGN.values();
		
		zodiacImages = new Image[allSigns.length];
		
		for (int n = 0; n < allSigns.length; n++)
		{
			PtPlanet.SIGN sign = allSigns[n];
			
			String imageName = sign.toString();
			String filePath = Systemf.getCurrentProjectDir(this) + "\\sign_pics\\" + imageName + ".png";
			
			BufferedImage image = null;
			try {
				image = ImageIO.read(new File(filePath));
			}
			catch (IOException e)
			{}
			
			if (image == null)
			{
				System.out.println("Couldn't find image at " + filePath);
			}
			else
			{
				zodiacImages[n] = image;
			}
		}
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		PtPlanetManager manager = Ptolemy.planetManager;
		
		if (manager == null || manager.getPlanets() == null)
			return;
		
		Graphics2D g2 = (Graphics2D) g;
		
		int centerX = this.getWidth() / 2;
		int centerY = this.getHeight() / 2;
		
		double zoomRatio = (double)zoom / 100;
		
		// Draw the signs of the zodiac in a circle
		if (manager.showZodiacSigns)
		{
			PtPlanet.SIGN[] allSigns = PtPlanet.SIGN.values();
			int radius = 225;
			
			for (int n = 0; n < allSigns.length; n++)
			{
				double signRadians = Mathf.DegToRad(allSigns[n].getDegrees());
				int offsetX = (int)(Math.sin(signRadians + Math.PI) * radius);
				int offsetY = (int)(Math.cos(signRadians + Math.PI) * radius);
				
				drawImageAtPointAndRotation(g2, allSigns[n], centerX + offsetX, centerY + offsetY, -allSigns[n].getDegrees(), 25);
			}
		}
		
		// Draw the planets' orbits and axes
		PtPlanet[] planets = manager.getPlanets();
		
		PtPlanet p = null;
		int size, planetX, planetY, defCenterX, defCenterY, defRadius, epiCenterX, epiCenterY, epiRadius;
		for (int i = planets.length - 1; i >= 0; i--)
		{
			p = planets[i];
			
			if (!p.getEnabled())
				continue;
			
			// Get a lot of variables from the planet, cast as ints
			size = p.getSize();
			defCenterX = (int)(p.getDefCenterX() * zoomRatio);
			defCenterY = (int)(p.getDefCenterY() * zoomRatio);
			defRadius = (int)(p.getDeferentRadius() * zoomRatio);
			epiCenterX = (int)(p.getEpiCenterX() * zoomRatio);
			epiCenterY = (int)(p.getEpiCenterY() * zoomRatio);
			epiRadius = (int)(p.getDeferentRadius() * p.getEpicyclicRadiusRatio() * zoomRatio);
			planetX = (int)(p.getPlanetX() * zoomRatio);
			planetY = (int)(p.getPlanetY() * zoomRatio);
			
			// Set the color for the orbits (black for now)
			g2.setColor(Color.black);
			
			// Draw the deferent orbit
			if (p.getShowDeferentRadius())
				g2.drawOval(centerX - defCenterX - defRadius, centerY - defCenterY - defRadius, defRadius * 2, defRadius * 2);
			
			// Draw the epicyclic orbit
			if (p.getShowEpicyclicRadius())
				g2.drawOval(centerX - epiCenterX - epiRadius, centerY - epiCenterY - epiRadius, epiRadius * 2, epiRadius * 2);
			
			// Draw the axes or lines
			PtPlanet.Axis[] axes = p.getAllAxes();
			if (axes != null && axes.length > 0)
			{
				for (PtPlanet.Axis axis : axes)
				{
					if (!axis.enabled || axis.point1 == PtPlanet.AXIS_POINT.Select || axis.point2 == PtPlanet.AXIS_POINT.Select)
						continue;
					
					Point point1 = PtPlanet.GetPointOfAxis(axis.point1, p);
					Point point2 = PtPlanet.GetPointOfAxis(axis.point2, p);
					g2.drawLine(centerX - (int)(point1.x * zoomRatio), centerY - (int)(point1.y * zoomRatio), centerX - (int)(point2.x * zoomRatio), centerY - (int)(point2.y * zoomRatio));
					//System.out.println("Drawing line from " + point1 + " to " + point2 + ".");
				}
			}
			
			
		}
		for (int i = planets.length - 1; i >= 0; i--)
		{
			p = planets[i];
			
			if (!p.getEnabled() || (!p.getShowPlanet() && !p.getName().equals("Earth")))
				continue;
			
			// Get a lot of variables from the planet, cast as ints
			size = (int)(p.getSize() * zoomRatio);
			planetX = (int)(p.getPlanetX() * zoomRatio);
			planetY = (int)(p.getPlanetY() * zoomRatio);
			
			// Draw the actual planet
			g2.setColor(p.getColor());
			g2.fillOval(centerX - planetX - size, centerY - planetY - size, size * 2, size * 2);
		}
		
		//double ariesInRadians = Mathf.DegToRad(PtPlanet.SIGN.Aries.getDegrees());
		//g2.drawLine(centerX, centerY, centerX - (int)Math.sin(ariesInRadians) * 1000, centerY - (int)Math.cos(ariesInRadians) * 1000);
		//System.out.printf("Drawing Aries line: %d, %d\n", (int)Math.sin(ariesInRadians), (int)Math.cos(ariesInRadians));
	}
	
	private void drawImageAtPointAndRotation(Graphics2D g2, PtPlanet.SIGN sign, int x, int y, int rotationInDeg, int height)
	{
		Image image = zodiacImages[sign.getDegrees() / 30];
		double rotationInRad = Mathf.DegToRad(rotationInDeg);
		
		g2.translate(x, y);
		g2.rotate(rotationInRad);
		
		g2.drawImage(image, - height / 2, - height / 2, height, height, null);
		
		g2.rotate(-rotationInRad);
		g2.translate(-x, -y);
	}
}
