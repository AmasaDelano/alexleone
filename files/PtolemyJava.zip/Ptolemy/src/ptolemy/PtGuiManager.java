package ptolemy;
import helper.Mathf;
import helper.Systemf;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.NumberFormatter;

import ptolemy.PtPlanet.AXIS_POINT;

import com.toedter.calendar.JCalendar;


public class PtGuiManager implements ActionListener
{
    // main window container
    private JFrame mainFrame;
    
    // main tab view
    private JTabbedPane mainTabbedPane;
    
    // Where all the stuff gets drawn
    private PtHeavensPanel mainPtolemyPanel;
    
    // Controls Panel elements
    private JButton stopStartButton;
    private SpinnerNumberModel showSecondsSpinnerModel;
    private JComboBox<Mathf.DISPLAY_TIME_UNIT> showSecondsComboBox;
    private SpinnerNumberModel inSecondsSpinnerModel;
    private JComboBox<Mathf.DISPLAY_TIME_UNIT> inSecondsComboBox;
    private JSlider zoomSlider;
    
    // Display Panel elements
    private JCheckBox showZodiacCheckBox;
    private JList<PtPlanet> planetSelectionList;
    private List<DisplayAxis> displayAxes;
    private JPanel rightPanel;
    private JPanel displayAxesPanel;
    private JCheckBox enableCheckBox;
    private JSlider deferentSizeSlider;
    private JCheckBox showPlanetCheckBox;
    private JSlider planetSizeSlider;
    private JCheckBox orbitsDeferentCheckBox;
    private JCheckBox orbitsEpicyclicCheckBox;
    private JCheckBox usesEquantCheckBox;
    
    // Manager
    private PtPlanetManager manager = null;
    
    public PtGuiManager()
    {
        manager = Ptolemy.planetManager;
        
        displayAxes = new ArrayList<DisplayAxis>();
    }
    public void setManager(PtPlanetManager newManager)
    {
        manager = newManager;
    } 
    
    public void createWindow()
    {
        mainFrame = new JFrame("Ptolemy's Heavens");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setMinimumSize(new Dimension(800, 600));
        
        mainTabbedPane = new JTabbedPane();
        mainFrame.add(mainTabbedPane);
        
        // Create Tab1
        JPanel tab1 = new JPanel(new BorderLayout());
        tab1.setName("Heavens");
        
        mainPtolemyPanel = new PtHeavensPanel();
        JPanel controlsPanel = createControlsPanel();
        
        tab1.add(mainPtolemyPanel, BorderLayout.CENTER);
        tab1.add(controlsPanel, BorderLayout.SOUTH);
        
        mainTabbedPane.add(tab1);
        
        // Create Tab2
        JPanel tab2 = createDisplayTab();
        updateDisplayOptionsFromPlanet(planetSelectionList.getSelectedValue());
        
        mainTabbedPane.add(tab2);
        
        // Create Tab2
        JPanel tab3 = createDatesTab();
        tab3.setName("Dates");
        
        //mainTabbedPane.add(tab3);
        
        // Final steps 
        mainFrame.pack();
        mainFrame.setVisible(true);
        
        lockStopStartButtonSize();
        
        mainPtolemyPanel.paintImmediately(mainFrame.getBounds());
    }
    private JPanel createControlsPanel()
    {
        JPanel controlsPanel = new JPanel(new BorderLayout());
        controlsPanel.setBorder(BorderFactory.createEtchedBorder());
        
        JPanel leftSide = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        stopStartButton = new JButton("Start");
        assignAction(stopStartButton, "Stop Start");
        
        JLabel showLabel = new JLabel("Show");
        
        // used for both text fields
        NumberFormatter fieldFormatter = new NumberFormatter();
        fieldFormatter.setValueClass(Integer.class);
        fieldFormatter.setMinimum(0);
        fieldFormatter.setAllowsInvalid(false);
        fieldFormatter.setMaximum(Integer.MAX_VALUE);
        
        showSecondsSpinnerModel = new SpinnerNumberModel(1, 1, 999, 1);
        JSpinner showSecondsSpinner = new JSpinner(showSecondsSpinnerModel);
        showSecondsSpinner.setEditor(new JSpinner.NumberEditor(showSecondsSpinner, "#"));
        showSecondsSpinner.addChangeListener(new ChangeListener()
        {
            @Override
            public void stateChanged(ChangeEvent e)
            {
                performAction("Update Speed");
            }
        });
        
        Mathf.DISPLAY_TIME_UNIT[] allUnits = Mathf.DISPLAY_TIME_UNIT.values();
        
        showSecondsComboBox = new JComboBox<Mathf.DISPLAY_TIME_UNIT>(allUnits);
        assignAction(showSecondsComboBox, "Update Speed");
        
        JLabel inLabel = new JLabel("in");
        
        inSecondsSpinnerModel = new SpinnerNumberModel(1, 1, 999, 1);
        JSpinner inSecondsSpinner = new JSpinner(inSecondsSpinnerModel);
        inSecondsSpinner.setEditor(new JSpinner.NumberEditor(inSecondsSpinner, "#"));
        inSecondsSpinner.addChangeListener(new ChangeListener()
        {
            @Override
            public void stateChanged(ChangeEvent e)
            {
                performAction("Update Speed");
            }
        });
        
        inSecondsComboBox = new JComboBox<Mathf.DISPLAY_TIME_UNIT>(allUnits);
        assignAction(inSecondsComboBox, "Update Speed");
        
        leftSide.add(stopStartButton);
        leftSide.add(showLabel);
        leftSide.add(showSecondsSpinner);
        leftSide.add(showSecondsComboBox);
        leftSide.add(inLabel);
        leftSide.add(inSecondsSpinner);
        leftSide.add(inSecondsComboBox);
        
        controlsPanel.add(leftSide, BorderLayout.WEST);
        
        JPanel rightSide = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        JLabel zoomLabel = new JLabel("Zoom:");
        rightSide.add(zoomLabel);
        
        zoomSlider = new JSlider(JSlider.HORIZONTAL, 1, 700, 100);
        zoomSlider.setPaintTicks(true);
        zoomSlider.addChangeListener(new ChangeListener()
        {
            @Override
            public void stateChanged(ChangeEvent e)
            {
                mainPtolemyPanel.setZoom(zoomSlider.getValue());
                refreshHeavens();
            }
        });
        rightSide.add(zoomSlider);
        
        controlsPanel.add(rightSide, BorderLayout.EAST);
        
        return controlsPanel;
    }
    
    private JPanel createDisplayTab()
    {
        JPanel displayTab = new JPanel(new BorderLayout(5, 5));
        displayTab.setName("Display");
        
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        planetSelectionList = new JList<PtPlanet>(manager.getPlanets());
        planetSelectionList.addListSelectionListener(new ListSelectionListener()
        {
            @Override
            public void valueChanged(ListSelectionEvent arg)
            {
                updateDisplayOptionsFromPlanet(planetSelectionList.getSelectedValue());
            }
        });
        planetSelectionList.setSelectedIndex(0);
        
        JPanel zodiacOptionsPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        showZodiacCheckBox = new JCheckBox("Show Zodiac");
        showZodiacCheckBox.setSelected(manager.showZodiacSigns);
        assignAction(showZodiacCheckBox, "Update Display Planet");
        JSlider zodiacRadiusSlider = new JSlider(0, 1000, 175);
        JSlider zodiacSizeSlider = new JSlider(0, 500, 25);
        
        leftPanel.add(planetSelectionList, BorderLayout.NORTH);
        leftPanel.add(showZodiacCheckBox, BorderLayout.SOUTH);
        
        displayTab.add(leftPanel, BorderLayout.WEST);
        
        rightPanel = createRightDisplayPanel();
        
        displayTab.add(rightPanel, BorderLayout.CENTER);
    
        return displayTab;
    }
    
    private JPanel createRightDisplayPanel()
    {
        return createRightDisplayPanel(null, (PtPlanet)planetSelectionList.getSelectedValue());
    }
    private JPanel createRightDisplayPanel(JPanel newRightPanel, PtPlanet planet)
    {
        if (newRightPanel == null)
        {
            newRightPanel = new JPanel(new GridBagLayout());
        }
        else
        {
            newRightPanel.removeAll();
        }
        
        //rightPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        GridBagConstraints rightPanelC = new GridBagConstraints();
        rightPanelC.anchor = GridBagConstraints.WEST;
        rightPanelC.gridx = 0;
        
        boolean enabled = planet.getEnabled();
        
        enableCheckBox = new JCheckBox("Enable");
        enableCheckBox.setSelected(enabled);
        assignAction(enableCheckBox, "Update Display Planet");
        newRightPanel.add(enableCheckBox, rightPanelC);
        
        if (planet != null && !planet.getName().equals("Earth"))
        {
            JPanel deferentSizeSliderPanel = new JPanel();
            JLabel deferentSizeLabel = new JLabel("Deferent Radius:");
            deferentSizeSlider = new JSlider(JSlider.HORIZONTAL, 1, 1000, Mathf.clamp(planet.getDeferentRadius(), 1, 1000));
            deferentSizeSlider.setEnabled(enabled);
            deferentSizeSlider.addChangeListener(new ChangeListener()
            {
                @Override
                public void stateChanged(ChangeEvent e)
                {
                    sliderPerformAction((JSlider)(e.getSource()), "Update Display Planet");
                }
            });
            deferentSizeSliderPanel.add(deferentSizeLabel);
            deferentSizeSliderPanel.add(deferentSizeSlider);
            newRightPanel.add(deferentSizeSliderPanel, rightPanelC);
            
            showPlanetCheckBox = new JCheckBox("Show Planet");
            showPlanetCheckBox.setEnabled(enabled);
            showPlanetCheckBox.setSelected(planet.getShowPlanet());
            assignAction(showPlanetCheckBox, "Update Display Planet");
            newRightPanel.add(showPlanetCheckBox, rightPanelC);
        }
        
        JPanel planetSizeSliderPanel = new JPanel();
        JLabel planetSizeLabel = new JLabel("Size:");
        planetSizeSlider = new JSlider(JSlider.HORIZONTAL, 1, 300, Mathf.clamp(planet.getSize(), 1, 300));
        planetSizeSlider.setEnabled(enabled);
        planetSizeSlider.addChangeListener(new ChangeListener()
        {
            @Override
            public void stateChanged(ChangeEvent e)
            {
                sliderPerformAction((JSlider)(e.getSource()), "Update Display Planet");
            }
        });
        planetSizeSliderPanel.add(planetSizeLabel);
        planetSizeSliderPanel.add(planetSizeSlider);
        newRightPanel.add(planetSizeSliderPanel, rightPanelC);
        
        if (planet != null && !planet.getName().equals("Earth"))
        {
            JLabel displayOrbitsLabel = new JLabel("Orbits:");
            orbitsDeferentCheckBox = new JCheckBox("Deferent");
            orbitsEpicyclicCheckBox = new JCheckBox("Epicyclic");
            orbitsDeferentCheckBox.setEnabled(enabled);
            orbitsEpicyclicCheckBox.setEnabled(enabled);
            orbitsDeferentCheckBox.setSelected(planet.getShowDeferentRadius());
            orbitsEpicyclicCheckBox.setSelected(planet.getShowEpicyclicRadius());
            assignAction(orbitsDeferentCheckBox, "Update Display Planet");
            assignAction(orbitsEpicyclicCheckBox, "Update Display Planet");
            newRightPanel.add(displayOrbitsLabel, rightPanelC);
            newRightPanel.add(orbitsDeferentCheckBox, rightPanelC);
            newRightPanel.add(orbitsEpicyclicCheckBox, rightPanelC);
            
            JLabel displayAxesLabel = new JLabel("Axes:");
            displayAxesPanel = createAxesPanel(planetSelectionList.getSelectedValue().getAllAxes());
            Systemf.enableComponents(displayAxesPanel, enabled);
            newRightPanel.add(displayAxesLabel, rightPanelC);
            newRightPanel.add(displayAxesPanel, rightPanelC);
            
            boolean isCustom = planet.getIsCustom();
            
            JLabel displayMeasurementsLabel = new JLabel("Measurements:");
            JPanel deferentMeasurementPanel = createMeasurementPanel("Deferent eccentricity", planet, planet.getEccentricRatio());
            JPanel epicyclicMeasurementPanel = createMeasurementPanel("Epicyclic radius ratio", planet, planet.getEpicyclicRadiusRatio());
            usesEquantCheckBox = new JCheckBox("Uses Equant");
            usesEquantCheckBox.setSelected(planet.getHasEquantCenter());
            Systemf.enableComponents(deferentMeasurementPanel, isCustom);
            Systemf.enableComponents(epicyclicMeasurementPanel, isCustom);
            usesEquantCheckBox.setEnabled(isCustom);
            newRightPanel.add(displayMeasurementsLabel, rightPanelC);
            newRightPanel.add(deferentMeasurementPanel, rightPanelC);
            newRightPanel.add(epicyclicMeasurementPanel, rightPanelC);
            newRightPanel.add(usesEquantCheckBox, rightPanelC);
            
            JLabel displaySpeedRatiosLabel = new JLabel("Speed Ratios:");
            JPanel deferentSpeedRatioPanel = createMeasurementPanel("Equant/Deferent rotation", planet, planet.getOrbitSpeedRatio());
            JPanel epicyclicSpeedRatioPanel = createMeasurementPanel("Epicyclic rotation", planet, planet.getEpicyclicSpeedRatio());
            Systemf.enableComponents(deferentSpeedRatioPanel, isCustom);
            Systemf.enableComponents(epicyclicSpeedRatioPanel, isCustom);
            newRightPanel.add(displaySpeedRatiosLabel, rightPanelC);
            newRightPanel.add(deferentSpeedRatioPanel, rightPanelC);
            newRightPanel.add(epicyclicSpeedRatioPanel, rightPanelC);
        }
        
        JPanel bottomFiller = new JPanel();
        JPanel rightFiller = new JPanel();
        
        rightPanelC.fill = GridBagConstraints.BOTH;
        rightPanelC.weightx = 0;
        rightPanelC.weighty = 1;
        newRightPanel.add(bottomFiller, rightPanelC);
        
        rightPanelC.gridx = 1;
        rightPanelC.gridheight = 100000;
        rightPanelC.weightx = 1;
        rightPanelC.weighty = 0;
        newRightPanel.add(rightFiller, rightPanelC);
        
        return newRightPanel;
    }
    private JPanel createAxesPanel(PtPlanet.Axis[] axes)
    {
        return createAxesPanel(axes, null);
    }
    private JPanel createAxesPanel(PtPlanet.Axis[] axes, JPanel panel)
    {
        if (panel == null)
        {
            panel = new JPanel(new GridLayout(0, 1));
        }
        else
        {
            panel.removeAll();
        }
            
        if (axes == null || axes.length <= 0)
            return panel;
        
        displayAxes.clear();
        
        for (PtPlanet.Axis axis : axes)
        {
            panel.add(createAxisPanel(axis));
        }
        
        return panel;
    }
    private JPanel createAxisPanel(PtPlanet.Axis axis)
    {
        JPanel newAxisPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        JCheckBox axisCheckBox = new JCheckBox();
        axisCheckBox.setSelected(axis.enabled);
        assignAction(axisCheckBox, "Update Display Planet");
        
        PtPlanet.AXIS_POINT[] allAxisPoints = PtPlanet.AXIS_POINT.values();
        
        JComboBox<PtPlanet.AXIS_POINT> point1ComboBox = new JComboBox<PtPlanet.AXIS_POINT>(allAxisPoints);
        point1ComboBox.setSelectedItem(axis.point1);
        assignAction(point1ComboBox, "Update Display Planet");
        
        //System.out.println("Point 1 : " + axis.point1 + ", " + point1ComboBox.getSelectedItem().toString());
        
        JLabel toLabel = new JLabel("to");
        
        JComboBox<PtPlanet.AXIS_POINT> point2ComboBox = new JComboBox<PtPlanet.AXIS_POINT>(allAxisPoints);
        point2ComboBox.setSelectedItem(axis.point2);
        assignAction(point2ComboBox, "Update Display Planet");
        
        //System.out.println("Point 2 : " + axis.point2 + ", " + point2ComboBox.getSelectedItem().toString());
        
        displayAxes.add(new DisplayAxis(point1ComboBox, point2ComboBox, axisCheckBox));
        
        newAxisPanel.add(axisCheckBox);
        newAxisPanel.add(point1ComboBox);
        newAxisPanel.add(toLabel);
        newAxisPanel.add(point2ComboBox);
        
        return newAxisPanel;
    }
    private JPanel createMeasurementPanel(String labelName, PtPlanet planet, double initialValue)
    {
        JPanel newMeasurementPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        int widthOfNumber = 5;
        
        JLabel label = new JLabel(labelName + ":");
        JTextField textField = new JTextField(widthOfNumber + 1);
        textField.setText(String.format("%1." + (widthOfNumber - 1) + "f", initialValue));
        
        newMeasurementPanel.add(label);
        newMeasurementPanel.add(textField);
        
        return newMeasurementPanel;
    }
    
    private JPanel createDatesTab()
    {
        JPanel datesTab = new JPanel();
        
        JCalendar datePicker = new JCalendar(Mathf.MOMENT_OF_EPOCH.toDate());
        //System.out.println(Mathf.MOMENT_OF_EPOCH);
        //System.out.println(Mathf.MOMENT_OF_EPOCH.toDate());
        
        datesTab.add(datePicker);
        
        return datesTab;
    }
    
    private void assignAction(AbstractButton comp, String action)
    {
        comp.addActionListener(this);
        comp.setActionCommand(action);
    }
    private void assignAction(JComboBox<?> comp, String action)
    {
        comp.addActionListener(this);
        comp.setActionCommand(action);
    }
    
    public void refreshHeavens()
    {
        mainPtolemyPanel.repaint();
    }
    
    private void lockStopStartButtonSize()
    {
        stopStartButton.setPreferredSize(stopStartButton.getSize());
    }

    private void sliderPerformAction(JSlider slider, String actionCommand)
    {
        if (actionCommand.equals("Update Display Planet"))
        {
            PtPlanet currentPlanet = planetSelectionList.getSelectedValue();
            
            updatePlanetFromDisplayOptions(currentPlanet);
            
            if (slider.getValueIsAdjusting())
            {
                updateDisplayOptionsFromPlanet(currentPlanet);
            }
            else
            {
                manager.setTime(manager.getTime());
                refreshHeavens();
            }
        }
    }
    private void performAction(String actionCommand)
    {
        long showSeconds = showSecondsSpinnerModel.getNumber().intValue() * ((Mathf.DISPLAY_TIME_UNIT)(showSecondsComboBox.getSelectedItem())).getValue();
        long inSeconds = inSecondsSpinnerModel.getNumber().intValue() * ((Mathf.DISPLAY_TIME_UNIT)(inSecondsComboBox.getSelectedItem())).getValue();
        
        // TAB1
        // Stop and start button
        if (actionCommand.equals("Stop Start"))
        {
            if (manager.isThreadRunning())
            {
                manager.stopMotion();
                stopStartButton.setText("Start");
            }
            else
            {
                manager.startMotion(showSeconds, inSeconds);
                stopStartButton.setText("Stop");
            }
        }
        // Speed drop down boxes and text fields
        else if (actionCommand.equals("Update Speed"))
        {
            manager.updateSpeed(showSeconds, inSeconds);
            // Speed drop down boxes and text fields
        }
        // TAB2
        else if (actionCommand.equals("Update Display Planet"))
        {
            PtPlanet currentPlanet = planetSelectionList.getSelectedValue();
            updatePlanetFromDisplayOptions(currentPlanet);
            updateDisplayOptionsFromPlanet(currentPlanet);
        }
    }
    @Override
    public void actionPerformed(ActionEvent a)
    {
        String actionCommand = a.getActionCommand();
        
        performAction(actionCommand);
    }
    
    private void updatePlanetFromDisplayOptions(PtPlanet currentDisplayPlanet)
    {
        if (currentDisplayPlanet == null)
            return;
        
        if (showZodiacCheckBox != null)
            manager.showZodiacSigns = showZodiacCheckBox.isSelected();
        
        if (enableCheckBox != null)
        {
            currentDisplayPlanet.setEnabled(enableCheckBox.isSelected());
            
            if (currentDisplayPlanet.getName().equals("Earth"))
                currentDisplayPlanet.setShowPlanet(enableCheckBox.isSelected());
        }
        
        if (deferentSizeSlider != null)
            currentDisplayPlanet.setDeferentRadius(deferentSizeSlider.getValue());
        
        if (showPlanetCheckBox != null)
            currentDisplayPlanet.setShowPlanet(showPlanetCheckBox.isSelected());
        
        if (planetSizeSlider != null)
            currentDisplayPlanet.setSize(planetSizeSlider.getValue());
        
        if (orbitsDeferentCheckBox != null)
            currentDisplayPlanet.setShowDeferentRadius(orbitsDeferentCheckBox.isSelected());
        
        if (orbitsEpicyclicCheckBox != null)
            currentDisplayPlanet.setShowEpicyclicRadius(orbitsEpicyclicCheckBox.isSelected());
        
        PtPlanet.Axis[] axes = currentDisplayPlanet.getAllAxes();
        if (displayAxes != null && axes != null)
        {   
            for (int n = 0; n < displayAxes.size(); n++)
            {   
                if (n >= axes.length)
                    break;
                
                DisplayAxis displayAxis = displayAxes.get(n);
                
                if (axes[n] == null || displayAxis == null)
                    continue;
                
                axes[n].point1 = (AXIS_POINT) displayAxis.axisPoint1.getSelectedItem();
                axes[n].point2 = (AXIS_POINT) displayAxis.axisPoint2.getSelectedItem();
                axes[n].enabled = displayAxis.enabled.isSelected();
                //System.out.println("Axis " + axes[n].point1 + " to " + axes[n].point2 + " is enabled: " + displayAxis.enabled.isSelected());
            }
        }
    }
    private void updateDisplayOptionsFromPlanet(PtPlanet newDisplayPlanet)
    {
        if (newDisplayPlanet == null)
        {
            return;
        }
        
        planetSelectionList.setSelectedValue(newDisplayPlanet, true);
        
        rightPanel = createRightDisplayPanel(rightPanel, newDisplayPlanet);
        
        manager.setTime(manager.getTime());
        
        refreshHeavens();
        
        mainFrame.repaint();
    }
    
    public class DisplayAxis
    {
        public JCheckBox enabled;
        public JComboBox<PtPlanet.AXIS_POINT> axisPoint1;
        public JComboBox<PtPlanet.AXIS_POINT> axisPoint2;
        
        public DisplayAxis(JComboBox<PtPlanet.AXIS_POINT> newAxisPoint1, JComboBox<PtPlanet.AXIS_POINT> newAxisPoint2, JCheckBox newEnabled)
        {
            axisPoint1 = newAxisPoint1;
            axisPoint2 = newAxisPoint2;
            enabled = newEnabled;
        }
    }
    
}
