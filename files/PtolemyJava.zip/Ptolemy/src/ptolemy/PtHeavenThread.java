package ptolemy;
import org.joda.time.DateTime;


public class PtHeavenThread extends Thread
{
	public boolean shouldRun = true;
	private long showSeconds = 1440; // real second
	private long inSeconds = 1; // simulated second
	
	public PtHeavenThread(long newShowSeconds, long newInSeconds)
	{
		showSeconds = newShowSeconds;
		inSeconds = newInSeconds;
	}
	
	public void setShowSeconds(long newShowSeconds)
	{
		showSeconds = newShowSeconds;
	}
	public void setInSeconds(long newInSeconds)
	{
		inSeconds = newInSeconds;
	}
	
	public void run()
	{
		long lastLoopTime = System.nanoTime();
		final int TARGET_FPS = 60;
		final long OPTIMAL_FRAME_TIME = 1000000000 / TARGET_FPS; // in nanoseconds (added 6 zeros from 1000 milliseconds)
		
		PtPlanetManager manager = Ptolemy.planetManager;
		PtGuiManager gui = Ptolemy.guiManager;
		DateTime newTime = manager.getTime();
		
		shouldRun = true;
		
		while (shouldRun)
		{
			long now = System.nanoTime();
			long updateLength = now - lastLoopTime;
			lastLoopTime = now;
			double delta = updateLength / ((double)OPTIMAL_FRAME_TIME);
			//System.out.println("Delta : " + delta);
			
			// calculate how many seconds to advance the time, then add it
			int secondsToAdd = (int) (((showSeconds / ((double)inSeconds)) / TARGET_FPS) * delta);
			newTime = manager.getTime().plusSeconds(secondsToAdd);
			manager.setTime(newTime);
			
			// refresh the view
			gui.refreshHeavens();
			
			// Add the optimal frame time to ((whatever time it was when this loop was last called) converted to milliseconds)
			// and sleep for that amount of time
			try
			{
				Thread.sleep( (long)((lastLoopTime - System.nanoTime() + OPTIMAL_FRAME_TIME) * 0.000001) );
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
}
