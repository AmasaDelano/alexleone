package helper;

import org.joda.time.DateTime;
import org.joda.time.chrono.GJChronology;

public class Mathf
{
	public static final double NUMBER_OF_DAYS_IN_A_YEAR = Mathf.PtHexToDec(365, 14, 48); // H208: Tropical. Sidereal is 365;15;25 days
	
	// H254: Year 1 of Nabonassar, Thoth 1 in the Egyptian calendar, noon (747 BC, Feb 26th at noon)
	public static final DateTime MOMENT_OF_EPOCH = new DateTime(-747, 2, 26, 12, 0, 0, GJChronology.getInstance());
	
	public static double DegToRad(double deg)
	{
		return deg * Math.PI / 180;
	}
	
	public static double RadToDeg(double rad)
	{
		return rad * 180 / Math.PI;
	}
	
	public enum DISPLAY_TIME_UNIT
	{
		SECOND(1),
		MINUTE(60),
		HOUR(3600),
		DAY(86400),
		WEEK(604800), // 7 days
		MONTH(2592000), // 30 days
		YEAR(31557600), // 365.25 days
		DECADE(315576000),
		CENTURY(3155760000L),
		MILLENIUM(31557600000L);
		
		private long value;
		
		DISPLAY_TIME_UNIT(long newValue) { value = (long)newValue; }
		public long getValue() { return value; }
		
		// in the future, make this depend on whether the number is plural or not
		public String toString() { return super.toString().toLowerCase() + "(s)"; }
	}
	
	public static double PtHexToDec(double ones, double... sixtiethsAndOther)
	{
		double result = ones;
		for (int n = 0; n < sixtiethsAndOther.length; n++)
		{
			result += sixtiethsAndOther[n] / Math.pow(60, n + 1);
		}
		return result;
	}
	public static double PtYearsToDeg(double years)
	{
		return (years * 360) / NUMBER_OF_DAYS_IN_A_YEAR;
	}
	public static double PtDegToYears(double degrees)
	{
		return (degrees * NUMBER_OF_DAYS_IN_A_YEAR) / 360;
	}
	
	public static int clamp01(int value)
	{
		return clamp(value, 0, 1);
	}
	public static int clamp(int value, int min, int max)
	{
		return Math.max(Math.min(value, max), min);
	}
}
