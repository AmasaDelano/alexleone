package helper;

import java.awt.Component;
import java.awt.Container;
import java.io.File;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Systemf
{
	public static void setSystemLookAndFeel()
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e1)
		{
			e1.printStackTrace();
		}
	}
	
	public static String getCurrentJarDir(Class<?> thisClass)
	{
		return thisClass.getProtectionDomain().getCodeSource().getLocation().getPath();
	}
	
	public static String getCurrentProjectDir(Object obj)
	{
		Class<?> thisClass = obj.getClass();
		return (new File(thisClass.getProtectionDomain().getCodeSource().getLocation().getPath())).getParent();
	}
	
	public static void enableComponents(Container container, boolean enable)
	{
		Component[] comps = container.getComponents();
		for (Component comp : comps)
		{
			comp.setEnabled(enable);
			
			if (comp instanceof Container)
			{
				enableComponents((Container)comp, enable);
			}
		}
	}
}
